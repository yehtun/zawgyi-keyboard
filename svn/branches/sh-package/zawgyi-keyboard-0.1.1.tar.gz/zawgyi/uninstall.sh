#!/bin/bash

#    zawgyi-keyboard - zawgyi keyboard installation for ubuntu.
#    Copyright (C) 2009  lrcmm.org
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Author: box02 (thebox02@gmail.com)
#    Sun May 24, 2009

a=1
b=2

FONTNAME=zawgyi
FONT_DIR=/usr/share/fonts
DOC_DIR=/usr/share/doc
DATA_DIR=/usr/share
XKB_DIR=/usr/share/X11/xkb/symbols
APPS_DIR=/usr/share/applications
ICONS_DIR=/usr/share/pixmaps

echo "\nzawgyi-keyboard  Copyright (C) 2009  lrcmm.org"
echo "\nThis program comes with ABSOLUTELY NO WARRANTY."
echo "This is free software, and you are welcome to redistribute it"
echo "under certain conditions; read the file LICENSE for details.\n"

echo "WARNING: Please run this script only if you installed zawgyi keyboard"
echo "previously from this package. Otherwise you needn't run this script!\n"
echo -n "Do you want to remove zawgyi keyboard?\n
If Yes - press [1] , NO - press [2] -: "
read c
# If you say "yes" .. this operation will start ..
if [ $c -eq $a ]
then

# remove files which had installed by the script which comes with this package.

rm -f $XKB_DIR/mm
rm -f $APPS_DIR/zawgyi.desktop
rm -f $ICONS_DIR/zawgyi.png
rm -rf $DATA_DIR/$FONTNAME
rm -rf $DOC_DIR/$FONTNAME
rm -rf $FONT_DIR/$FONTNAME
 
# restore original 'mm' file
echo "Restoring the original keyboard..."
cp $XKB_DIR/mm_orig $XKB_DIR/mm
sleep 1
echo "zawgyi keyboard is successfully removed!"
echo "Good bye!\n"
fi

# If you say "no" .. the operation will stop ..
if [ $c -eq $b ]
then
echo
echo "nothing to do!\n"
fi
