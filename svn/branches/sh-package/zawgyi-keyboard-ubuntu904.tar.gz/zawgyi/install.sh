#!/bin/bash

#    zawgyi-keyboard - zawgyi keyboard installation for ubuntu.
#    Copyright (C) 2009  lrcmm.org
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#    Author: box02 (thebox02@gmail.com)
#    Sun Apr 26, 2009

echo "\nzawgyi-keyboard  Copyright (C) 2009  lrcmm.org"
echo "\nThis program comes with ABSOLUTELY NO WARRANTY."
echo "This is free software, and you are welcome to redistribute it"
echo "under certain conditions; read the file LICENSE for details.\n"

a=1
b=2

echo -n "WARNING: This operation will remove your Old zawgyi-keyboard if it had been installed!\n
Do you want to continuous this operation?\n
If Yes - press [1] , NO - press [2] -: "
read c
# If you say "yes" .. this operation will start ..
if [ $c -eq $a ]
then

# removing old zawgyi-keyboard deb package
dpkg -l | grep zawgyi-keyboard | sudo dpkg -r zawgyi-keyboard

# backup original xkb symbol mm
sudo mv /usr/share/X11/xkb/symbols/mm /usr/share/X11/xkb/symbols/mm_bak

#cd ~/Desktop/zawgyi/

# font installation
echo "Installing font..."
sudo mkdir /usr/share/fonts/zawgyi
sudo cp -vf *.ttf /usr/share/fonts/zawgyi/
sudo fc-cache -vf /usr/share/fonts/zawgyi/
sleep 1
echo "Installing font completed!\n"

# installing zawgyi keyboard
echo "Installing keyboard..."
sudo cp -vf mm /usr/share/X11/xkb/symbols/
sleep 1
echo "Installing keyboard completed!\n"

# prepare keyboard layout preferences
# echo "Layout Preferences preparing ..."
# setxkbmap -model pc104 -layout us,mm -variant ,zawgyi
# setxkbmap -option -option grp:alt_shift_toggle,lv3:win_switch
# echo

echo "Done!\n"
fi

# If you say "no" .. the operation will stop ..
if [ $c -eq $b ]
then
echo
echo "nothing to do!\n"
fi

